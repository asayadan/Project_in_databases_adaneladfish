select * from cancellations R where R.CAUSE = 'because' 
