select * from payments
