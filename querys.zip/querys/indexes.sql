create index indexOrdersStartDate on
orders (start_date);

create index cancellaionsIndex on
cancellations (cause);

create index extrasIndex on
extrasfororders (extra_id);

 
